package edu.pradita.oop.session_vehicle;

/**
 * MOTORCYCLE CLASS - TODO: Inheritance + Override!
 */
public class Motorcycle extends Vehicle {
    
    // TODO 12: Tambah 1 private field khusus Motorcycle
    // private boolean ____;

    // TODO 13: Constructor overload (2 versi)
    // - Motorcycle(3 param) → call this()
    // - Motorcycle(4 param) → call super()
    public Motorcycle(/* TODO */) {
        // TODO: this() atau super()
    }

    // TODO 14: Override start() → "Motorcycle engine is starting..."
    @Override
    public void start() {
        // TODO: Override
    }

    // TODO 15: Override honk() → "Motorcycle horn: Beep!"
    @Override
    public void honk() {
        // TODO: Override
    }

    // TODO 16: 1 getter khusus Motorcycle
    // public boolean hasFairing() { return false; }
}
