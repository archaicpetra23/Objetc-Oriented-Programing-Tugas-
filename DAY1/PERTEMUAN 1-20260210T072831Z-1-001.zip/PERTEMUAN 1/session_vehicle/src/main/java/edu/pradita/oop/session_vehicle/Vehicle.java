package edu.pradita.oop.session_vehicle;

/**
 * SUPERCLASS - Lengkapi TODO!
 */
public class Vehicle {
    
    // TODO 1: Buat 3 private field
    // private String ____;
    // private String ____;
    // private int ____;

    // TODO 2: Constructor dengan 3 parameter
    public Vehicle(/* TODO: parameter */) {
        // TODO: Inisialisasi field dengan parameter
    }

    // TODO 3: Method start() - print "Vehicle is starting..."
    public void start() {
        // TODO: Implement
    }

    // TODO 4: Method honk() - print "Beep!"
    public void honk() {
        // TODO: Implement
    }

    // TODO 5: Method getDescription() - return "YEAR BRAND MODEL"
    public String getDescription() {
        // TODO: Implement
        return null;
    }

    // TODO 6: 3 getter method
    // public String getBrand() { return null; }
    // public String getModel() { return null; }
    // public int getYear() { return 0; }
}
