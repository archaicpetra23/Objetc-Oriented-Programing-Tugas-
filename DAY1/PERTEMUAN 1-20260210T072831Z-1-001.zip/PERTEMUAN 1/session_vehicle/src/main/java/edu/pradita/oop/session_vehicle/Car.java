package edu.pradita.oop.session_vehicle;

/**
 * CAR CLASS - TODO: Inheritance + Override!
 */
public class Car extends Vehicle {
    
    // TODO 7: Tambah 1 private field khusus Car
    // private int ____;

    // TODO 8: Constructor overload (2 versi)
    // - Car(3 param) → call this()
    // - Car(4 param) → call super()
    public Car(/* TODO */) {
        // TODO: this() atau super()
    }

    // TODO 9: Override start() → "Car engine is starting..."
    @Override
    public void start() {
        // TODO: Override
    }

    // TODO 10: Override honk() → "Car horn: Beep Beep!"
    @Override
    public void honk() {
        // TODO: Override
    }

    // TODO 11: 1 getter khusus Car
    // public int getNumberOfDoors() { return 0; }
}
